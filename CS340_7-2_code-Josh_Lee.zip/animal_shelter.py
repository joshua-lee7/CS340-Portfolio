from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter:

    def __init__(self, user='aacuser', password='SNHU1234',
                 host='nv-desktop-services.apporto.com', port=33069,
                 db_name='AAC', collection_name='animals'):
        """
        Initialize the MongoDB client and connect to the specified collection.
        """
        try:
            uri = f'mongodb://{user}:{password}@{host}:{port}/?authSource=admin'
            self.client = MongoClient(uri)
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
            print("✅ Connected to MongoDB successfully.")
        except ConnectionFailure as e:
            print("❌ MongoDB connection error:", e)
            raise

    def create(self, data):
        """Insert a single document into the collection."""
        if data and isinstance(data, dict):
            try:
                print("📦 Inserting document:", data)
                result = self.collection.insert_one(data)
                print("✅ Inserted document ID:", result.inserted_id)
                return result.acknowledged
            except Exception as e:
                print("❌ Insert error:", e)
                return False
        else:
            print("⚠️ Data must be a non-empty dictionary.")
            return False

    def read(self, query):
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"Read failed: {e}")
            return []

    def update(self, query, update_values):
        if query is not None and update_values is not None:
            try:
                update_result = self.collection.update_many(query, {'$set': update_values})
                return update_result.modified_count
            except Exception as e:
                print(f"Update failed: {e}")
                return 0
        else:
            raise Exception("Query or update values missing")

    def delete(self, query):
        if query is not None:
            try:
                delete_result = self.collection.delete_many(query)
                return delete_result.deleted_count
            except Exception as e:
                print(f"Delete failed: {e}")
                return 0
        else:
            raise Exception



